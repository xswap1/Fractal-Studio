import discord
from discord.ext import commands
import re
import json
import os
from datetime import datetime

# Bot configuration
class BotConfig:
    def __init__(self):
        self.config_file = 'config.json'
        self.load_config()
    
    def load_config(self):
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                data = json.load(f)
                self.monitored_channels = set(data.get('monitored_channels', []))
                self.log_channel = data.get('log_channel', None)
                self.exempt_roles = set(data.get('exempt_roles', []))
        else:
            self.monitored_channels = set()
            self.log_channel = None
            self.exempt_roles = set()
    
    def save_config(self):
        data = {
            'monitored_channels': list(self.monitored_channels),
            'log_channel': self.log_channel,
            'exempt_roles': list(self.exempt_roles)
        }
        with open(self.config_file, 'w') as f:
            json.dump(data, f, indent=2)

# Initialize bot
intents = discord.Intents.default()
# Message content intent is required to read message content
# You must enable this in Discord Developer Portal under Bot > Privileged Gateway Intents
intents.message_content = True
bot = discord.Bot(intents=intents)
config = BotConfig()

# URL regex pattern
URL_PATTERN = re.compile(
    r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
)

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    print(f'Bot is ready and monitoring {len(config.monitored_channels)} channels')
    
    # Sync slash commands for faster testing and debugging
    try:
        await bot.sync_commands()
        # Get the actual commands from the bot
        commands = bot.pending_application_commands
        print(f'✅ Successfully synced {len(commands)} slash commands')
        for cmd in commands:
            print(f'   • /{cmd.name} - {cmd.description}')
    except Exception as e:
        print(f'❌ Failed to sync commands: {e}')
    
    print('🚀 Bot is fully ready!')

@bot.event
async def on_message(message):
    # Ignore bot messages
    if message.author.bot:
        return
    
    # Check if message is in a monitored channel
    if message.channel.id in config.monitored_channels:
        # Check if user has an exempt role
        user_role_ids = {role.id for role in message.author.roles}
        if config.exempt_roles.intersection(user_role_ids):
            return  # User has an exempt role, skip link checking
        
        # Check for URLs in the message
        if URL_PATTERN.search(message.content):
            # Store message info before deletion
            author = message.author
            channel = message.channel
            content = message.content
            
            # Delete the message first
            await message.delete()
            
            # Create enhanced embed for the user
            embed = discord.Embed(
                title="🚫 Link Removed",
                description="**Links are not allowed in this channel!**\n\n🔒 Your message has been automatically deleted to keep the channel clean.",
                color=0xFF4444,  # Bright red
                timestamp=datetime.utcnow()
            )
            embed.add_field(
                name="📍 Channel",
                value=f"{channel.mention}",
                inline=True
            )
            embed.add_field(
                name="⏰ Time",
                value=f"<t:{int(datetime.utcnow().timestamp())}:R>",
                inline=True
            )
            embed.add_field(
                name="💡 Tip",
                value="Contact a moderator if you need to share a link!",
                inline=False
            )
            embed.set_footer(
                text="💰 Get 10% extra earnings: https://t.me/undefined?start=U-893924",
                icon_url="https://cdn.discordapp.com/emojis/741243929892864041.png"
            )
            embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/692028527405547580.png")
            
            # Try to send DM to user (ephemeral-like behavior)
            try:
                await author.send(embed=embed)
            except (discord.Forbidden, discord.HTTPException):
                # If DM fails, send ephemeral response (visible only to user for 15 seconds)
                try:
                    # Create a more discreet channel message that auto-deletes
                    temp_embed = discord.Embed(
                        description=f"🔒 {author.mention}, your link was removed. Check your DMs for details!",
                        color=0xFF6B6B
                    )
                    await channel.send(embed=temp_embed, delete_after=15)
                except discord.Forbidden:
                    pass  # Bot doesn't have permission to send messages
            
            # Log the deletion if log channel is set
            if config.log_channel:
                log_channel = bot.get_channel(config.log_channel)
                if log_channel:
                    log_embed = discord.Embed(
                        title="🗑️ Link Deletion Log",
                        description="A message containing links was automatically deleted.",
                        color=0xFFA500,  # Orange
                        timestamp=datetime.utcnow()
                    )
                    log_embed.add_field(
                        name="👤 User", 
                        value=f"{author.mention}\n`{author}` (ID: {author.id})", 
                        inline=True
                    )
                    log_embed.add_field(
                        name="📍 Channel", 
                        value=f"{channel.mention}\n`#{channel.name}`", 
                        inline=True
                    )
                    log_embed.add_field(
                        name="⏰ Timestamp", 
                        value=f"<t:{int(datetime.utcnow().timestamp())}:F>", 
                        inline=True
                    )
                    log_embed.add_field(
                        name="📝 Message Content", 
                        value=f"```{content[:1000] if len(content) <= 1000 else content[:997] + '...'}```", 
                        inline=False
                    )
                    log_embed.set_footer(
                        text=f"CarbonBot • User ID: {author.id}",
                        icon_url=author.display_avatar.url
                    )
                    log_embed.set_thumbnail(url=author.display_avatar.url)
                    
                    try:
                        await log_channel.send(embed=log_embed)
                    except discord.Forbidden:
                        pass  # Bot doesn't have permission to send to log channel
    
    await bot.process_commands(message)

@bot.slash_command(name="set_monitored_channels", description="Set channels to monitor for links (Admin only)")
async def set_monitored_channels(ctx: discord.ApplicationContext, channels: str):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Parse channel mentions
    channel_ids = re.findall(r'<#(\d+)>', channels)
    
    if not channel_ids:
        await ctx.respond("❌ Please mention at least one channel using #channel-name", ephemeral=True)
        return
    
    # Validate channels exist
    valid_channels = []
    for channel_id in channel_ids:
        channel = bot.get_channel(int(channel_id))
        if channel and channel.guild.id == ctx.guild.id:
            valid_channels.append(channel)
    
    if not valid_channels:
        await ctx.respond("❌ No valid channels found in this server.", ephemeral=True)
        return
    
    # Update monitored channels
    config.monitored_channels = {channel.id for channel in valid_channels}
    config.save_config()
    
    channel_list = "\n".join([f"• {channel.mention}" for channel in valid_channels])
    
    embed = discord.Embed(
        title="✅ Monitored Channels Updated",
        description=f"🔍 **Now monitoring the following channels for links:**\n\n{channel_list}",
        color=0x00FF88,  # Bright green
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/705423711792013312.png")
    
    await ctx.respond(embed=embed, ephemeral=True)

@bot.slash_command(name="add_monitored_channel", description="Add a channel to monitor for links (Admin only)")
async def add_monitored_channel(ctx: discord.ApplicationContext, channel: discord.TextChannel):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Check if channel is in the same guild
    if channel.guild.id != ctx.guild.id:
        await ctx.respond("❌ Channel must be in this server.", ephemeral=True)
        return
    
    # Add channel to monitored list
    config.monitored_channels.add(channel.id)
    config.save_config()
    
    embed = discord.Embed(
        title="✅ Channel Added",
        description=f"🎯 **Successfully added {channel.mention} to monitored channels.**\n\nLinks will now be automatically deleted in this channel.",
        color=0x00FF88,  # Bright green
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    
    await ctx.respond(embed=embed, ephemeral=True)

@bot.slash_command(name="remove_monitored_channel", description="Remove a channel from monitoring (Admin only)")
async def remove_monitored_channel(ctx: discord.ApplicationContext, channel: discord.TextChannel):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Remove channel from monitored list
    if channel.id in config.monitored_channels:
        config.monitored_channels.remove(channel.id)
        config.save_config()
        
        embed = discord.Embed(
            title="✅ Channel Removed",
            description=f"🗑️ **Successfully removed {channel.mention} from monitored channels.**\n\nLinks will no longer be monitored in this channel.",
            color=0x00FF88,  # Bright green
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    else:
        embed = discord.Embed(
            title="ℹ️ Channel Not Monitored",
            description=f"📋 **{channel.mention} was not being monitored.**\n\nNo changes were made to the configuration.",
            color=0x3498DB,  # Blue
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    
    await ctx.respond(embed=embed, ephemeral=True)

@bot.slash_command(name="set_log_channel", description="Set the channel for logging deleted messages (Admin only)")
async def set_log_channel(ctx: discord.ApplicationContext, channel: discord.TextChannel):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Check if channel is in the same guild
    if channel.guild.id != ctx.guild.id:
        await ctx.respond("❌ Channel must be in this server.", ephemeral=True)
        return
    
    # Set log channel
    config.log_channel = channel.id
    config.save_config()
    
    embed = discord.Embed(
        title="✅ Log Channel Set",
        description=f"📝 **Log channel successfully set to {channel.mention}**\n\nAll link deletions will now be logged here.",
        color=0x00FF88,  # Bright green
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    
    await ctx.respond(embed=embed, ephemeral=True)

@bot.slash_command(name="show_config", description="Show current bot configuration (Admin only)")
async def show_config(ctx: discord.ApplicationContext):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    embed = discord.Embed(
        title="🤖 CarbonBot Configuration",
        description="📊 **Current bot settings and monitored channels**",
        color=0x7289DA,  # Discord blurple
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    embed.set_thumbnail(url=bot.user.display_avatar.url)
    
    # Monitored channels
    if config.monitored_channels:
        channels = []
        for channel_id in config.monitored_channels:
            channel = bot.get_channel(channel_id)
            if channel:
                channels.append(f"• {channel.mention}")
        
        if channels:
            embed.add_field(
                name="📋 Monitored Channels",
                value="\n".join(channels),
                inline=False
            )
        else:
            embed.add_field(
                name="📋 Monitored Channels",
                value="No valid channels found",
                inline=False
            )
    else:
        embed.add_field(
            name="📋 Monitored Channels",
            value="None configured",
            inline=False
        )
    
    # Log channel
    if config.log_channel:
        log_channel = bot.get_channel(config.log_channel)
        if log_channel:
            embed.add_field(
                name="📝 Log Channel",
                value=log_channel.mention,
                inline=False
            )
        else:
            embed.add_field(
                name="📝 Log Channel",
                value="Channel not found",
                inline=False
            )
    else:
        embed.add_field(
            name="📝 Log Channel",
            value="None configured",
            inline=False
        )
    
    # Exempt roles
    if config.exempt_roles:
        roles = []
        for role_id in config.exempt_roles:
            role = ctx.guild.get_role(role_id)
            if role:
                roles.append(f"• {role.mention}")
        
        if roles:
            embed.add_field(
                name="🛡️ Exempt Roles",
                value="\n".join(roles),
                inline=False
            )
        else:
            embed.add_field(
                name="🛡️ Exempt Roles",
                value="No valid roles found",
                inline=False
            )
    else:
        embed.add_field(
            name="🛡️ Exempt Roles",
            value="None configured",
            inline=False
        )
    
    await ctx.respond(embed=embed, ephemeral=True)

@bot.slash_command(name="sync_commands", description="Manually sync all slash commands (Admin only)")
async def sync_commands(ctx: discord.ApplicationContext):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Defer the response since syncing might take a moment
    await ctx.defer(ephemeral=True)
    
    try:
        # Sync commands
        await bot.sync_commands()
        
        # Get the actual commands from the bot
        commands = bot.pending_application_commands
        
        # Create success embed
        embed = discord.Embed(
            title="✅ Commands Synced Successfully",
            description=f"🔄 **Successfully synced {len(commands)} slash commands**\n\nAll commands should now be available immediately in Discord.",
            color=0x00FF88,  # Bright green
            timestamp=datetime.utcnow()
        )
        
        # Add command list
        if commands:
            command_list = "\n".join([f"• `/{cmd.name}` - {cmd.description}" for cmd in commands[:10]])  # Limit to first 10
            if len(commands) > 10:
                command_list += f"\n... and {len(commands) - 10} more commands"
            
            embed.add_field(
                name="📋 Synced Commands",
                value=command_list,
                inline=False
            )
        
        embed.set_footer(text="CarbonBot Command Sync", icon_url=bot.user.display_avatar.url)
        embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/784463793499693066.png")
        
        await ctx.followup.send(embed=embed, ephemeral=True)
        
    except Exception as e:
        # Create error embed
        error_embed = discord.Embed(
            title="❌ Command Sync Failed",
            description=f"**Failed to sync slash commands:**\n\n```{str(e)}```\n\nPlease try again or contact support if the issue persists.",
            color=0xFF4444,  # Red
            timestamp=datetime.utcnow()
        )
        error_embed.set_footer(text="CarbonBot Command Sync", icon_url=bot.user.display_avatar.url)
        
        await ctx.followup.send(embed=error_embed, ephemeral=True)

@bot.slash_command(name="set_exempt_roles", description="Set roles that are exempt from link monitoring (Admin only)")
async def set_exempt_roles(ctx: discord.ApplicationContext, roles: str):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Parse role mentions
    role_ids = re.findall(r'<@&(\d+)>', roles)
    
    if not role_ids:
        await ctx.respond("❌ Please mention at least one role using @role-name", ephemeral=True)
        return
    
    # Validate roles exist
    valid_roles = []
    for role_id in role_ids:
        role = ctx.guild.get_role(int(role_id))
        if role:
            valid_roles.append(role)
    
    if not valid_roles:
        await ctx.respond("❌ No valid roles found in this server.", ephemeral=True)
        return
    
    # Update exempt roles
    config.exempt_roles = {role.id for role in valid_roles}
    config.save_config()
    
    role_list = "\n".join([f"• {role.mention}" for role in valid_roles])
    
    embed = discord.Embed(
        title="✅ Exempt Roles Updated",
        description=f"🛡️ **The following roles are now exempt from link monitoring:**\n\n{role_list}\n\nUsers with these roles can post links freely in monitored channels.",
        color=0x00FF88,  # Bright green
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/671078089421725696.png")
    
    await ctx.respond(embed=embed, ephemeral=True)

@bot.slash_command(name="add_exempt_role", description="Add a role to exempt from link monitoring (Admin only)")
async def add_exempt_role(ctx: discord.ApplicationContext, role: discord.Role):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Add role to exempt list
    config.exempt_roles.add(role.id)
    config.save_config()
    
    embed = discord.Embed(
        title="✅ Exempt Role Added",
        description=f"🛡️ **Successfully added {role.mention} to exempt roles.**\n\nUsers with this role can now post links freely in monitored channels.",
        color=0x00FF88,  # Bright green
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    
    await ctx.respond(embed=embed, ephemeral=True)

@bot.slash_command(name="remove_exempt_role", description="Remove a role from link monitoring exemption (Admin only)")
async def remove_exempt_role(ctx: discord.ApplicationContext, role: discord.Role):
    # Check if user has administrator permissions
    if not ctx.author.guild_permissions.administrator:
        await ctx.respond("❌ You need administrator permissions to use this command.", ephemeral=True)
        return
    
    # Remove role from exempt list
    if role.id in config.exempt_roles:
        config.exempt_roles.remove(role.id)
        config.save_config()
        
        embed = discord.Embed(
            title="✅ Exempt Role Removed",
            description=f"🗑️ **Successfully removed {role.mention} from exempt roles.**\n\nUsers with this role will now be subject to link monitoring.",
            color=0x00FF88,  # Bright green
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    else:
        embed = discord.Embed(
            title="ℹ️ Role Not Exempt",
            description=f"📋 **{role.mention} was not in the exempt roles list.**\n\nNo changes were made to the configuration.",
            color=0x3498DB,  # Blue
            timestamp=datetime.utcnow()
        )
        embed.set_footer(text="CarbonBot Configuration", icon_url=bot.user.display_avatar.url)
    
    await ctx.respond(embed=embed, ephemeral=True)

# Run the bot
if __name__ == "__main__":
    # Try to load environment variables from .env file
    try:
        from load_env import load_env_from_file
        load_env_from_file()
    except ImportError:
        print("Note: load_env.py not found. Continuing with existing environment variables.")
    
    # Get the bot token from environment variables
    TOKEN = os.getenv('DISCORD_BOT_TOKEN')
    if not TOKEN:
        print("\033[91mERROR: DISCORD_BOT_TOKEN not found!\033[0m")
        print("Please set the DISCORD_BOT_TOKEN environment variable or create a .env file.")
        print("You can get a token from: https://discord.com/developers/applications")
        print("\nExample .env file content:")
        print("DISCORD_BOT_TOKEN=your_token_here")
        
        # Check if running in Windows and provide additional instructions
        if os.name == 'nt':
            print("\nOn Windows, you can set the environment variable with:")
            print("set DISCORD_BOT_TOKEN=your_token_here")
    else:
        print("\033[92mToken found! Starting bot...\033[0m")
        try:
            bot.run(TOKEN)
        except discord.errors.LoginFailure:
            print("\033[91mERROR: Invalid token. Please check your DISCORD_BOT_TOKEN.\033[0m")
        except Exception as e:
            print(f"\033[91mERROR: Failed to start bot: {e}\033[0m")