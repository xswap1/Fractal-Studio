import os
import re

def load_env_from_file(env_file='.env'):
    """
    Load environment variables from a .env file into os.environ
    
    Args:
        env_file (str): Path to the .env file
        
    Returns:
        bool: True if file was loaded successfully, False otherwise
    """
    try:
        if not os.path.exists(env_file):
            print(f"Warning: {env_file} file not found.")
            return False
            
        with open(env_file, 'r') as f:
            for line in f:
                # Skip comments and empty lines
                if line.startswith('#') or not line.strip():
                    continue
                    
                # Parse key-value pairs
                match = re.match(r'^([A-Za-z0-9_]+)=(.*)$', line.strip())
                if match:
                    key, value = match.groups()
                    # Remove quotes if present
                    value = value.strip('\'"')
                    os.environ[key] = value
                    
        return True
    except Exception as e:
        print(f"Error loading {env_file}: {e}")
        return False

if __name__ == "__main__":
    # This allows the script to be run directly to test loading .env file
    success = load_env_from_file()
    if success:
        print("Environment variables loaded successfully.")
        # Print loaded variables (except sensitive ones)
        for key, value in os.environ.items():
            if 'TOKEN' in key or 'SECRET' in key or 'PASSWORD' in key or 'KEY' in key:
                print(f"{key}=***HIDDEN***")
            else:
                print(f"{key}={value}")
    else:
        print("Failed to load environment variables.")