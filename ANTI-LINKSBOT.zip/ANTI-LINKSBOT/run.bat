@echo off
echo Starting CarbonBot...
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python is not installed or not in PATH. Please install Python 3.8 or higher.
    echo Visit https://www.python.org/downloads/ to download Python.
    pause
    exit /b
)

REM Check if requirements are installed
echo Checking dependencies...
pip install -r requirements.txt

REM Run the bot
echo Starting bot...
python bot.py

pause