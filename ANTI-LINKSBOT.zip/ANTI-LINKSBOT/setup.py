#!/usr/bin/env python3
"""
CarbonBot Setup Script
This script helps you set up the CarbonBot Discord moderation bot.
"""

import os
import sys
import subprocess
import shutil

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required.")
        print(f"Current version: {sys.version}")
        print("Please upgrade Python and try again.")
        return False
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} detected")
    return True

def check_pip():
    """Check if pip is available"""
    try:
        subprocess.run([sys.executable, "-m", "pip", "--version"], 
                      check=True, capture_output=True)
        print("✅ pip is available")
        return True
    except subprocess.CalledProcessError:
        print("❌ pip is not available")
        print("Please install pip and try again.")
        return False

def install_requirements():
    """Install required packages"""
    print("📦 Installing requirements...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], 
                      check=True)
        print("✅ Requirements installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install requirements: {e}")
        return False
    except FileNotFoundError:
        print("❌ requirements.txt not found")
        return False

def create_env_file():
    """Create .env file if it doesn't exist"""
    if os.path.exists('.env'):
        print("ℹ️  .env file already exists")
        return True
    
    if os.path.exists('.env.example'):
        try:
            shutil.copy('.env.example', '.env')
            print("✅ Created .env file from .env.example")
            print("📝 Please edit .env file and add your Discord bot token")
            return True
        except Exception as e:
            print(f"❌ Failed to create .env file: {e}")
            return False
    else:
        # Create a basic .env file
        try:
            with open('.env', 'w') as f:
                f.write("# Discord Bot Token (Required)\n")
                f.write("# Get this from https://discord.com/developers/applications\n")
                f.write("DISCORD_BOT_TOKEN=your_bot_token_here\n")
            print("✅ Created .env file")
            print("📝 Please edit .env file and add your Discord bot token")
            return True
        except Exception as e:
            print(f"❌ Failed to create .env file: {e}")
            return False

def get_bot_token():
    """Prompt user for bot token and update .env file"""
    print("\n🤖 Discord Bot Token Setup")
    print("To get a bot token:")
    print("1. Go to https://discord.com/developers/applications")
    print("2. Create a new application or select an existing one")
    print("3. Go to the 'Bot' section")
    print("4. Click 'Add Bot' if you haven't already")
    print("5. Copy the token")
    
    while True:
        token = input("\nEnter your Discord bot token (or 'skip' to configure later): ").strip()
        
        if token.lower() == 'skip':
            print("⏭️  Skipping token configuration")
            return True
        
        if len(token) < 50:  # Discord tokens are typically much longer
            print("❌ That doesn't look like a valid Discord bot token")
            continue
        
        # Update .env file
        try:
            # Read current .env content
            env_content = ""
            if os.path.exists('.env'):
                with open('.env', 'r') as f:
                    env_content = f.read()
            
            # Replace or add the token
            lines = env_content.split('\n')
            token_updated = False
            
            for i, line in enumerate(lines):
                if line.startswith('DISCORD_BOT_TOKEN='):
                    lines[i] = f'DISCORD_BOT_TOKEN={token}'
                    token_updated = True
                    break
            
            if not token_updated:
                lines.append(f'DISCORD_BOT_TOKEN={token}')
            
            # Write back to .env
            with open('.env', 'w') as f:
                f.write('\n'.join(lines))
            
            print("✅ Bot token saved to .env file")
            return True
            
        except Exception as e:
            print(f"❌ Failed to save token: {e}")
            return False

def main():
    """Main setup function"""
    print("🚀 CarbonBot Setup")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        return False
    
    # Check pip
    if not check_pip():
        return False
    
    # Install requirements
    if not install_requirements():
        return False
    
    # Create .env file
    if not create_env_file():
        return False
    
    # Get bot token
    if not get_bot_token():
        return False
    
    print("\n" + "=" * 50)
    print("✅ Setup completed successfully!")
    print("\n📋 Next steps:")
    print("1. Make sure your bot token is set in the .env file")
    print("2. Invite the bot to your Discord server with appropriate permissions")
    print("3. Run the bot with: python bot.py")
    print("\n🔗 Bot invite permissions needed:")
    print("   - Send Messages")
    print("   - Manage Messages")
    print("   - Use Slash Commands")
    print("   - View Channels")
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        if not success:
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⏹️  Setup cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error during setup: {e}")
        sys.exit(1)