# CarbonBot - Professional Discord Link Moderation Bot

A professional Discord moderation bot built with Python and py-cord 2.6.1 that automatically detects and removes links from specified channels.

## Features

- 🔗 **Automatic Link Detection**: Monitors specified channels for any HTTP/HTTPS links
- 🗑️ **Instant Deletion**: Automatically removes messages containing links
- 📨 **User Notification**: Sends private messages to users explaining why their message was deleted
- 📝 **Comprehensive Logging**: Logs all deleted messages to a designated log channel
- ⚙️ **Easy Configuration**: Simple slash commands for administrators to manage settings
- 🛡️ **Permission-Based**: Only administrators can configure the bot

## Installation

### Prerequisites

- Python 3.8 or higher
- A Discord bot token

### Setup Steps

1. **Clone or download this repository**
   ```bash
   git clone <repository-url>
   cd ANTI-LINKSBOT
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Create a Discord Application**
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - Click "New Application" and give it a name (e.g., "CarbonBot")
   - Go to the "Bot" section and click "Add Bot"
   - **IMPORTANT**: Under "Privileged Gateway Intents", enable "Message Content Intent"
     - This is REQUIRED for the bot to read message content and detect links
   - Copy the bot token

4. **Set up the bot token**
   
   **Option A: Environment Variable (Recommended)**
   ```bash
   # Windows
   set DISCORD_BOT_TOKEN=your_bot_token_here
   
   # Linux/Mac
   export DISCORD_BOT_TOKEN=your_bot_token_here
   ```
   
   **Option B: Direct in code**
   - Edit `bot.py` and replace the TOKEN line with:
   ```python
   TOKEN = "your_bot_token_here"
   ```

5. **Invite the bot to your server**
   - In the Discord Developer Portal, go to "OAuth2" > "URL Generator"
   - Select scopes: `bot` and `applications.commands`
   - Select bot permissions: `Send Messages`, `Manage Messages`, `Use Slash Commands`
   - Copy the generated URL and open it to invite the bot

6. **Run the bot**
   ```bash
   python bot.py
   ```

## Usage

### Slash Commands (Admin Only)

All commands require administrator permissions to use.

#### `/set_monitored_channels`
Set multiple channels to monitor for links at once.
- **Usage**: `/set_monitored_channels channels:#channel1 #channel2 #channel3`
- **Example**: `/set_monitored_channels channels:#general #chat #memes`

#### `/add_monitored_channel`
Add a single channel to the monitoring list.
- **Usage**: `/add_monitored_channel channel:#channel-name`
- **Example**: `/add_monitored_channel channel:#general`

#### `/remove_monitored_channel`
Remove a channel from the monitoring list.
- **Usage**: `/remove_monitored_channel channel:#channel-name`
- **Example**: `/remove_monitored_channel channel:#general`

#### `/set_log_channel`
Set the channel where deleted message logs will be sent.
- **Usage**: `/set_log_channel channel:#log-channel`
- **Example**: `/set_log_channel channel:#mod-logs`

#### `/show_config`
Display the current bot configuration.
- **Usage**: `/show_config`
- Shows all monitored channels and the current log channel

## How It Works

1. **Link Detection**: The bot uses regex pattern matching to detect HTTP/HTTPS URLs in messages
2. **Automatic Deletion**: When a link is detected in a monitored channel, the message is immediately deleted
3. **User Notification**: The bot attempts to send a private message to the user explaining the deletion
4. **Logging**: If a log channel is configured, the bot sends detailed information about the deleted message

## Configuration Storage

The bot automatically saves its configuration to `config.json`. This file includes:
- List of monitored channel IDs
- Log channel ID

The configuration persists between bot restarts.

## Permissions Required

The bot needs the following permissions in your Discord server:
- `Send Messages` - To send notifications and log messages
- `Manage Messages` - To delete messages containing links
- `Use Slash Commands` - To register and use slash commands
- `View Channels` - To monitor messages in specified channels

## Troubleshooting

### Privileged Intents Error
If you see an error about "privileged intents that have not been explicitly enabled":
- Go to [Discord Developer Portal](https://discord.com/developers/applications)
- Select your application
- Go to "Bot" section
- Scroll down to "Privileged Gateway Intents"
- Enable "Message Content Intent"
- Save changes and restart your bot

### Bot not responding to commands
- Ensure the bot has the required permissions
- Check that slash commands are synced (should happen automatically on startup)
- Verify the bot token is correct

### Links not being detected
- Confirm the channel is added to the monitored channels list using `/show_config`
- Check that the bot has `Manage Messages` permission in that channel
- Verify "Message Content Intent" is enabled in Discord Developer Portal

### Users not receiving notifications
- The bot tries to send private messages first
- If DMs are disabled, users won't receive notifications (this is a Discord limitation)

### Logs not appearing
- Ensure a log channel is set using `/set_log_channel`
- Verify the bot has `Send Messages` permission in the log channel

## Security Notes

- Never share your bot token publicly
- Use environment variables for the token in production
- Only give administrator permissions to trusted users
- Regularly review the monitored channels list

## Support

If you encounter any issues or need help setting up the bot, please check the troubleshooting section above or create an issue in the repository.

## Promotional Footer

The bot includes a promotional footer in user notifications: "Get 10% extra earnings: https://t.me/undefined?start=U-893924"

---

**CarbonBot** - Professional Discord Link Moderation Made Simple